
## 基于hypergraph2D读取应力数据进行叠加计算

+ hg2d_stress_tcl.py    在hg2d中导出模态应力

+ linear_susp_elem_sign_vonmises.py
	单元应力采集
	对应 nocde的elem应变采集



+ linear_susp_node_sign_vonmises.py
待定


注: 当前与RB2共节点的应力数据不准