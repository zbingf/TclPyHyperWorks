
import os

"""
    <Channel>
      <!--  -->
      <!-- <tabfat id="1" type="Time Data">#rps_path#</tabfat> -->
      #Channel#
    </Channel>
    <FatigeEvents>
      #FatigeEvents#
      <Event Configuration="superposition" Gate="0" id="1" name="xml_run_1">
      	<!-- block  -->
      	<!-- tabfatId req file ID -->
      	<!-- subcase  -->
        <Fatload LDM="1" Offset="0" Scale="1" block="4" resultfile="" sim="1" subcase="1" tabfatId="1" tabfatName=""></Fatload>
        <Fatload LDM="1" Offset="0" Scale="1" block="5" resultfile="" sim="1" subcase="2" tabfatId="1" tabfatName=""></Fatload>
        <Fatload LDM="1" Offset="0" Scale="1" block="6" resultfile="" sim="1" subcase="3" tabfatId="1" tabfatName=""></Fatload>
      </Event>

      <Event Configuration="superposition" Gate="0" id="2" name="xml_run_2">
        <Fatload LDM="1" Offset="0" Scale="1" block="7" resultfile="" sim="1" subcase="1" tabfatId="2" tabfatName=""></Fatload>
        <Fatload LDM="1" Offset="0" Scale="1" block="8" resultfile="" sim="1" subcase="2" tabfatId="2" tabfatName=""></Fatload>
        <Fatload LDM="1" Offset="0" Scale="1" block="9" resultfile="" sim="1" subcase="3" tabfatId="2" tabfatName=""></Fatload>
      </Event>

    </FatigeEvents>
"""


LOADCASE_SINGLE = """
BeginDerivedSubcase : #BeginDerivedSubcase#
    Format = basic
    Title = #title#
    BeginSimulation : 1
        subcase = #subcase#
        simulation = #simulation#
        scale = 1
    EndSimulation
EndDerivedSubcase
#######################
"""

# rsp ID, 
TABFAT_SINGLE = '<tabfat id="{}" type="Time Data">{}</tabfat>\n'
EVENT_START = '<Event Configuration="superposition" Gate="0" id="{}" name="{}">\n'
EVENT_END = '</Event>\n'

# 通道, 工况, rsp ID
FATLOAD_SINGLE = '<Fatload LDM="1" Offset="0" Scale="1" block="{}" resultfile="" sim="1" subcase="{}" tabfatId="{}" tabfatName=""></Fatload>\n'


def file_read(file_path):
	with open(file_path, 'r') as f:
		file_str = f.read()

	return file_str


def flexbody_loadcase_create(loadcase_path, mode_ranges, subcase_id, simulation_add=1, cur_loadcase_start_zero=1000):

	loadcase_strs = []
	for n in range(mode_ranges[0], mode_ranges[1]+1):
		title = 'mode {}'.format(n)
		subcase = str(subcase_id)
		simulation = str(n+simulation_add)
		cur_loadcase_id = str(n+cur_loadcase_start_zero)

		single_n = LOADCASE_SINGLE

		for a,b in zip(['#BeginDerivedSubcase#', '#title#', '#subcase#', '#simulation#'],
			[cur_loadcase_id, title, subcase, simulation]):
		
			single_n = single_n.replace(a,b)

		# print(single_n)
		loadcase_strs.append(single_n)

	with open(loadcase_path, 'w') as f:
		for line in loadcase_strs:
			f.write(line)

	return None


def tabfat_set(rsp_id, rsp_path):

	return TABFAT_SINGLE.format(rsp_id, rsp_path)


def fatload_set(rsp_id, new_subcase_id, channel_id):
	
	return FATLOAD_SINGLE.format(channel_id, new_subcase_id, rsp_id)



def event_set(event_id, event_name, event_strs):
	# 
	# event_strs : fatload_list
	# 
	event_str = EVENT_START.format(event_id, event_name)

	event_set_str = event_str + ''.join(event_strs) + EVENT_END

	return event_set_str



file_path = r'C:\Users\zheng.bingfeng\Downloads\hyperlife_tpl_v01.xml'
new_file_path = r'C:\Users\zheng.bingfeng\Downloads\hyperlife_auto.xml'
loadcase_path = r'C:\Users\zheng.bingfeng\Downloads\hyperlife_v01.cfg'


rsp_path = r'D:/04_FastCalc/K9MD_HyperLife/Q_1.rsp'
model_path = r'E:/00_program/K9MD_Q4/K9MD_dw0353_Static_rev01_211220_modal_superposion.h3d'
result_path = model_path
mode_ranges = [7, 204]
channel_ranges = [1, 198]
subcase_id = 100
cur_loadcase_start_zero=1000
simulation_add=1
rsp_paths = [rsp_path]


print('--start--')
file_str = file_read(file_path)
flexbody_loadcase_create(loadcase_path, mode_ranges, subcase_id, simulation_add=simulation_add, cur_loadcase_start_zero=cur_loadcase_start_zero)
tabfat_str = ''.join([tabfat_set(n+1, rsp_path) for n, rsp_path_n in enumerate(rsp_paths)])

for n, rsp_path_n in enumerate(rsp_paths):
	rsp_id = n+1
	event_id = n+1
	event_name = 'event_auto_{}_{}'.format(event_id, os.path.basename(rsp_path_n)[:-4])
	fatload_list = []
	event_list = []

	cur_loadcase_ids = [id_n+cur_loadcase_start_zero for id_n in range(mode_ranges[0], mode_ranges[1]+1)]

	for mode_n, channel_n in zip(cur_loadcase_ids, range(channel_ranges[0], channel_ranges[1]+1)):
		fatload_list.append(fatload_set(rsp_id, mode_n, channel_n))
	fatload_str = ''.join(fatload_list)

	event_list.append(event_set(event_id, event_name, fatload_list))

event_str = ''.join(event_list)


#ModelFile#
#ResultFile#
#DerivedLoadcase#
#Channel#
#FatigeEvents#
for a, b in zip(['#ModelFile#', '#ResultFile#', '#DerivedLoadcase#', '#Channel#', '#FatigeEvents#'],
	[model_path.replace('\\','/'), result_path.replace('\\','/'), loadcase_path.replace('\\','/'), tabfat_str, event_str]):
	file_str = file_str.replace(a, b)


with open(new_file_path, 'w') as f:
	f.write(file_str)


print('--end--')

