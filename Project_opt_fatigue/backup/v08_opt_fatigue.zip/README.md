

# optistruct-耐久计算集成
## 输入参数
+ flexbody.h3d 目标柔性体h3d文件
+ optistruct_fatigue.fem 耐久计算用fem基础文件未拆分set及设置路径前
+ optistruct.bat 解算器调用文件
+ motionsolve_result.mrf(s) 计算结果mrf文件
+ base_folder_path 基础文件夹路径
+ set_limit 单元截取限制, default:15000
+ set_id_range 计算目标set的ID范围

## 流程
1. 创建文件夹
	+ 02_fem: 分割后的fem存放路径
	+ 03_autocalc: 调整后fems存放路径,及指定的计算路径
	+ 04_result_h3d: 计算完成后的h3d存放路径
	+ 05_result_stat: 结果文件之一stat, 记录计算过程即时长
	+ 06_sus_h3d: 空文件加用于存放叠加后的h3d文件

2. 分割fem set
	+ 存放于 02_fem: path_fem
	+ fem_split_lists 列表

3. 重新定义fem路径
	+ 存放于 03_autocalc: path_autocalc
	+ fem_new_lists 列表
	+ 确认文件数量

4. 开始计算fem文件
	+ 自动计算路径: path_autocalc
	+ 计算返回

5. 移动数据
	+ 结果h3d移动到 04_result_h3d: path_result_h3d
		+ result_h3d_lists 列表
	+ 结果stat移动到 05_result_stat: path_result_stat
		+ result_stat_lists 列表

6. 统计计算时长
	+ 解析 result_stat_lists 中的文件数据

## 更改
1. stat_time_read.py  stat_time_read(stat_paths, recode_path)
2. py_bat_opt_run.py  opt_run(opt_path, run_dir, is_break=False) new_fem_paths
3. fatigue_fem_path_edit.py fatigue_fem_path_edit(fem_paths, h3d_path, mrf_paths) new_fem_paths
4. fatigue_fem_fatdef_split_limit.py split_fatigue_fatdef_set_limit(fem_path, set_range, max_num=15000) new_fem_paths 




