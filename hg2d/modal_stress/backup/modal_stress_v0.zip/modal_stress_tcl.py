"""
    tcl命令生成
    hypergraph2d 导出模态应力数据
        单元element数据导出
"""

import tk_ui
TkUi = tk_ui.TkUi

import re
import os
import logging
import os.path
PY_FILE_NAME = os.path.basename(__file__).replace('.py', '')
LOG_PATH = PY_FILE_NAME+'.log'


tcl_path = '__temp.txt'
cmd_path = 'modal_stress_tcl.txt'


def tcl_command_create(file_path, element_ids):

    if isinstance(element_ids, int):
        element_ids = [element_ids]

    # ===============================
    # 命令
    with open(cmd_path, 'r') as f:
        cmd_str = f.read()

    # 写入
    f = open(tcl_path, 'w')
    file_path = file_path.replace('\\\\', '/')

    for element_id in element_ids:

        new_cmd_str = cmd_str.replace('#file_path#', file_path).replace('#id#', str(element_id))
        new_cmd_str = new_cmd_str.replace('#xy_path#', file_path[:-4]+f'_E{element_id}.txt')
        print(new_cmd_str)
        f.write(new_cmd_str+'\n\n')

    f.close()
    os.popen(tcl_path)
    return None



class ModalStressTclUi(TkUi):

    def __init__(self, title, frame=None):
        super().__init__(title, frame=frame)

        self.frame_loadpath({
            'frame':'result_file_path', 'var_name':'result_file_path', 'path_name':'result_file(h3d,op2..)',
            'path_type':'.*', 'button_name':'result_file(h3d,op2..)',
            'button_width':20, 'entry_width':40,
            })

        self.frame_entry({
            'frame':'element_ids', 'var_name':'element_ids', 'label_text':'element_ids',
            'label_width':20, 'entry_width':40,
            })


        self.frame_buttons_RWR({
            'frame' : 'rrw',
            'button_run_name' : '运行',
            'button_write_name' : '保存',
            'button_read_name' : '读取',
            'button_width' : 15,
            'func_run' : self.fun_run,
            })

        self.frame_note()


    def fun_run(self):

        self.print('开始计算')

        params = self.get_vars_and_texts()

        result_file_path = params['result_file_path']
        element_ids = params['element_ids']

        tcl_command_create(result_file_path, element_ids)


        self.print('计算完成')



if __name__=='__main__':
    
    ModalStressTclUi('ModalStress-Tcl').run()



    # # 获取文件
    # file_path = tkinter.filedialog.askopenfilename(filetypes = (('files',['*.*']),))
    # element_ids = [680, 693]

    # tcl_command_create(file_path, element_ids)