"""

    XY_data读取 及 数据处理

"""

import tk_ui
TkUi = tk_ui.TkUi

import rsp_read
RpcFile = rsp_read.RpcFile

import re
import os
import os.path

# import logging
# PY_FILE_NAME = os.path.basename(__file__).replace('.py', '')
# LOG_PATH = PY_FILE_NAME+'.log'


def xy_data_read(file_path):

    with open(file_path, 'r') as f:
        lines = [line for line in f.read().split('\n') if line]

    element_data = {}
    loc = 1
    for line in lines:

        if "XYDATA" in line.upper():
            groups = re.match('XYDATA\s*,\s*(\S+)\s*\((\S+)\).*', line).groups()
            data_type, surface = groups
            
            element_data[(data_type,surface)] = []
            continue
        if "ENDATA" in line.upper():
            continue

        value = float([value for value in line.split(' ') if value][-1])
        element_data[(data_type,surface)].append(value)

    return element_data


def get_target_modal_channel(element_data, channels):

    new_element_data = {}
    for key in element_data:
        list1 = element_data[key]
        new_element_data[key] = [list1[channel] for channel in channels]
    return new_element_data


# 叠加计算
def modal_superposition(element_data, rpc_data):

    ms_element_data = {}
    nlen = len(rpc_data[0])
    for key in element_data:
        list1 = []
        for n_line in range(nlen):
            value = 0
            for n_modal in range(len(rpc_data)):
                value += element_data[key][n_modal]*rpc_data[n_modal][n_line]
            list1.append(value)

        ms_element_data[key] = list1



    return ms_element_data, nlen


# 带方向米塞斯应力计算-2D
def get_sign_vonmises_2d(ms_element_data, nlen):

    # 数据长度 nlen

    sign_vonmises_data = {}

    face_types = ['Z1', 'Z2']
    for face_type in face_types:
        list1 = []
        for n in range(nlen):
            xy = ms_element_data[('XY',face_type)][n]
            xx = ms_element_data[('XX',face_type)][n]
            yy = ms_element_data[('YY',face_type)][n]

            p1 = (xx+yy)/2 + ( ((xx-yy)/2)**2 + xy**2 )**0.5
            p3 = (xx+yy)/2 - ( ((xx-yy)/2)**2 + xy**2 )**0.5
            if abs(p1) < abs(p3):
                p1, p3 = p3, p1
            p2 = 0

            vonmises = (((p1-p2)**2+(p2-p3)**2+(p3-p1)**2)/2)**0.5

            if p1 < 0:
                vonmises = -vonmises

            list1.append(vonmises)

        sign_vonmises_data[face_type] = list1

    return sign_vonmises_data


# 主函数
def sign_vonmises_cal(file_path, modal_channels, rpc_path, rpc_channels):

    name2 = os.path.basename(rpc_path)
    csv_path  = file_path[:-4]+f'_{name2}_result.csv'

    # rsp数据
    rpc_obj = RpcFile(rpc_path, 'test')
    rpc_obj.read_file()
    rpc_obj.set_select_channels(rpc_channels)
    rpc_data = rpc_obj.get_data()
    rpc_samplerate = rpc_obj.get_samplerate()

    element_data = xy_data_read(file_path)
    

    # 模态通道选择
    if modal_channels!=None:
        if isinstance(modal_channels, int):
            modal_channels = [modal_channels]
        new_element_data = get_target_modal_channel(element_data, modal_channels)
    else:
        new_element_data = element_data

    ms_element_data, nlen = modal_superposition(new_element_data, rpc_data)
    # print(ms_element_data)

    sign_vonmises_data = get_sign_vonmises_2d(ms_element_data, nlen)
    # time_data = [ n/rpc_samplerate for n in range(nlen) ]

    f = open(csv_path[:-4]+f'_{rpc_samplerate:0.0f}Hz.csv', 'w')

    # f.write('time(s),Sign_VonMises(Z1),Sign_VonMises(Z2)\n')
    f.write('Sign_VonMises(Z1),Sign_VonMises(Z2)\n')
    # for t, sign_vonmises_z1, sign_vonmises_z2 in zip(time_data, sign_vonmises_data['Z1'], sign_vonmises_data['Z2']):
    for sign_vonmises_z1, sign_vonmises_z2 in zip(sign_vonmises_data['Z1'], sign_vonmises_data['Z2']):
        # f.write(f'{t},{sign_vonmises_z1},{sign_vonmises_z2}\n')
        f.write(f'{sign_vonmises_z1},{sign_vonmises_z2}\n')


    f.close()



class SignVonmisesUi(TkUi):

    def __init__(self, title, frame=None):
        super().__init__(title, frame=frame)

        self.frame_loadpaths({
            'frame':'ms_files', 'var_name':'ms_files', 'path_name':'modal stress XY-DATA',
            'path_type':'.*', 'button_name':'modal stress XY-DATA',
            'button_width':20, 'entry_width':40,
            })

        self.frame_entry({
            'frame':'modal_channels', 'var_name':'modal_channels', 'label_text':'modal_channels',
            'label_width':20, 'entry_width':40,
            })

        self.frame_loadpath({
            'frame':'rpc_path', 'var_name':'rpc_path', 'path_name':'rpc_path',
            'path_type':'.*', 'button_name':'rpc_path',
            'button_width':20, 'entry_width':40,
            })

        self.frame_entry({
            'frame':'rpc_channels', 'var_name':'rpc_channels', 'label_text':'rpc_channels',
            'label_width':20, 'entry_width':30,
            })

        self.frame_buttons_RWR({
            'frame' : 'rrw',
            'button_run_name' : '运行',
            'button_write_name' : '保存',
            'button_read_name' : '读取',
            'button_width' : 15,
            'func_run' : self.fun_run,
            })

        self.frame_note()

        self.vars['modal_channels'].set('None')
        self.vars['rpc_channels'].set('None')

    def fun_run(self):

        self.print('开始计算')
        params = self.get_vars_and_texts()

        ms_files = params['ms_files']
        rpc_path = params['rpc_path']
        modal_channels = params['modal_channels']
        rpc_channels   = params['rpc_channels']

        if isinstance(ms_files, str): ms_files = [ms_files]

        for ms_file in ms_files:
            sign_vonmises_cal(ms_file, modal_channels, rpc_path, rpc_channels)

        # print(sign_vonmises_data)

        self.print('计算完成')



if __name__=='__main__':
    
    SignVonmisesUi('SignVonmisesUi').run()
