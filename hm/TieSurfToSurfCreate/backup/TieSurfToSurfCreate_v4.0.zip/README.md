# TieSurfToSurfCreate

### 软件版本
+ hypermesh 2017

### 功能
+ 创建Tie接触-面对面

-----------------
### 前置参数
	+ 网格1与网格2的间距允许 mm
	+ 网格1与网格2各自法向量的夹角允许 deg
	+ 网格1与网格2连接处的法向量夹角允许 deg

-----------------
### 操作
1. 选择网格1
2. 选择网格2
3. 设置控制参数, Tie接触名称
4. 在网格1与2间创建Tie接触

-----------------
### 版本更替
+ v4.0 
	+ 利用\*feoutput_select 选择性导出 elem及node
	```tcl
	proc print_elem_node_to_fem {fem_path elem_ids} {
		# 导出指定单元数据到fem
		set altair_dir [hm_info -appinfo ALTAIR_HOME]
		set optistruct_path [format "%s/templates/feoutput/optistruct/optistruct" $altair_dir]
		# elems 1
		eval "*createmark elems 1 $elem_ids"
		# nodes 1
		hm_createmark nodes 1 "by elem" $elem_ids
		# 导出
		hm_answernext yes
		*feoutput_select "$optistruct_path" $fem_path 1 0 0
	}
	```
